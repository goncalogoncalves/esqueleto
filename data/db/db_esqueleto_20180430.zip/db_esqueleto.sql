-- --------------------------------------------------------
-- Anfitrião:                    127.0.0.1
-- Versão do servidor:           5.7.11 - MySQL Community Server (GPL)
-- Server OS:                    Win64
-- HeidiSQL Versão:              9.5.0.5277
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

-- Dumping structure for table esqueleto.crud
CREATE TABLE IF NOT EXISTS `crud` (
  `crud_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `record_created_date` datetime DEFAULT CURRENT_TIMESTAMP,
  `record_created_by` int(10) DEFAULT NULL COMMENT 'user id',
  `record_changed_date` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `record_changed_by` int(10) DEFAULT NULL COMMENT 'user id',
  PRIMARY KEY (`crud_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table esqueleto.crud: ~0 rows (approximately)
/*!40000 ALTER TABLE `crud` DISABLE KEYS */;
INSERT INTO `crud` (`crud_id`, `name`, `record_created_date`, `record_created_by`, `record_changed_date`, `record_changed_by`) VALUES
	(1, '66666', '2015-12-07 18:10:18', 4, '2015-12-07 18:21:14', NULL);
/*!40000 ALTER TABLE `crud` ENABLE KEYS */;

-- Dumping structure for table esqueleto.definition
CREATE TABLE IF NOT EXISTS `definition` (
  `definition_id` int(10) NOT NULL AUTO_INCREMENT,
  `website_name` varchar(255) DEFAULT NULL,
  `website_description` varchar(500) DEFAULT NULL,
  `website_keywords` varchar(255) DEFAULT NULL,
  `website_url` varchar(255) DEFAULT NULL,
  `website_email_administrator` varchar(500) DEFAULT NULL,
  `video` varchar(500) DEFAULT NULL,
  `facebook_url` varchar(500) DEFAULT NULL,
  `twitter_url` varchar(500) DEFAULT NULL,
  `local_latitude` varchar(50) DEFAULT NULL,
  `local_longitude` varchar(50) DEFAULT NULL,
  `company_name` varchar(500) DEFAULT NULL,
  `company_abbreviation` varchar(500) DEFAULT NULL,
  `company_address` varchar(500) DEFAULT NULL,
  `company_postal_code` varchar(500) DEFAULT NULL,
  `company_locale` varchar(500) DEFAULT NULL,
  `company_country` varchar(500) DEFAULT NULL,
  `company_email` varchar(500) DEFAULT NULL,
  `company_email_comercial` varchar(500) DEFAULT NULL,
  `company_nif` varchar(500) DEFAULT NULL,
  `company_nib` varchar(500) DEFAULT NULL,
  `company_telephone` varchar(500) DEFAULT NULL,
  `company_fax` varchar(500) DEFAULT NULL,
  `anniversary_interval_days` int(10) DEFAULT NULL,
  `salesman_commission` decimal(10,2) DEFAULT NULL,
  PRIMARY KEY (`definition_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table esqueleto.definition: ~1 rows (approximately)
/*!40000 ALTER TABLE `definition` DISABLE KEYS */;
INSERT INTO `definition` (`definition_id`, `website_name`, `website_description`, `website_keywords`, `website_url`, `website_email_administrator`, `video`, `facebook_url`, `twitter_url`, `local_latitude`, `local_longitude`, `company_name`, `company_abbreviation`, `company_address`, `company_postal_code`, `company_locale`, `company_country`, `company_email`, `company_email_comercial`, `company_nif`, `company_nib`, `company_telephone`, `company_fax`, `anniversary_interval_days`, `salesman_commission`) VALUES
	(1, 'Esqueleto', 'PHP MVC skeleton', 'php,mvc', NULL, 'devgoncalo@gmail.com', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
/*!40000 ALTER TABLE `definition` ENABLE KEYS */;

-- Dumping structure for table esqueleto.language
CREATE TABLE IF NOT EXISTS `language` (
  `lang_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `abbreviation` varchar(255) DEFAULT NULL,
  `active` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`lang_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- Dumping data for table esqueleto.language: ~5 rows (approximately)
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
INSERT INTO `language` (`lang_id`, `name`, `abbreviation`, `active`) VALUES
	(1, 'Português', 'pt', 1),
	(2, 'English', 'en', 1),
	(3, 'Français', 'fr', 0),
	(4, 'Español', 'es', 1),
	(5, 'Deutsch', 'de', 0);
/*!40000 ALTER TABLE `language` ENABLE KEYS */;

-- Dumping structure for table esqueleto.log
CREATE TABLE IF NOT EXISTS `log` (
  `log_id` int(10) NOT NULL AUTO_INCREMENT,
  `priority` varchar(255) DEFAULT '0',
  `message` longtext,
  `date_created` datetime DEFAULT NULL,
  `solved` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- Dumping data for table esqueleto.log: ~0 rows (approximately)
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
/*!40000 ALTER TABLE `log` ENABLE KEYS */;

-- Dumping structure for table esqueleto.log_frontend
CREATE TABLE IF NOT EXISTS `log_frontend` (
  `log_frontend_id` int(10) NOT NULL AUTO_INCREMENT,
  `message` varchar(255) DEFAULT NULL,
  `error` varchar(255) DEFAULT NULL,
  `local` varchar(255) DEFAULT NULL,
  `referer` varchar(255) DEFAULT NULL,
  `user_ip` varchar(255) DEFAULT NULL,
  `record_created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `record_created_by` varchar(255) DEFAULT NULL,
  `record_changed_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `record_changed_by` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`log_frontend_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2054 DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

-- Dumping data for table esqueleto.log_frontend: ~0 rows (approximately)
/*!40000 ALTER TABLE `log_frontend` DISABLE KEYS */;
INSERT INTO `log_frontend` (`log_frontend_id`, `message`, `error`, `local`, `referer`, `user_ip`, `record_created_date`, `record_created_by`, `record_changed_date`, `record_changed_by`) VALUES
	(2052, '', '404', '/page/1', '', '127.0.0.1', '2018-04-30 14:20:53', 'User not logged in', '2018-04-30 14:20:53', NULL),
	(2053, '', '404', '/page/1', '', '127.0.0.1', '2018-04-30 14:22:40', 'not_logged_in', '2018-04-30 14:22:40', NULL);
/*!40000 ALTER TABLE `log_frontend` ENABLE KEYS */;

-- Dumping structure for table esqueleto.page
CREATE TABLE IF NOT EXISTS `page` (
  `page_id` int(10) NOT NULL AUTO_INCREMENT,
  `page_id_father` int(10) DEFAULT '0',
  `title` varchar(255) NOT NULL,
  `content` longtext NOT NULL,
  `visible` tinyint(4) DEFAULT '1',
  `lang_id` int(11) NOT NULL,
  `private` tinyint(4) NOT NULL DEFAULT '0',
  `page_type_id` int(10) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `seo_title` varchar(500) DEFAULT NULL,
  `seo_description` varchar(500) DEFAULT NULL,
  `seo_keywords` varchar(500) DEFAULT NULL,
  `date_created` datetime DEFAULT NULL,
  `date_changed` datetime DEFAULT NULL,
  `number_views` varchar(255) DEFAULT NULL,
  `record_created_date` datetime NOT NULL,
  `record_created_by` int(10) NOT NULL,
  `record_changed_date` datetime DEFAULT NULL,
  `record_changed_by` int(10) DEFAULT NULL,
  PRIMARY KEY (`page_id`,`lang_id`),
  KEY `fk_paginas_paginas_tipos1_idx` (`page_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT;

-- Dumping data for table esqueleto.page: ~2 rows (approximately)
/*!40000 ALTER TABLE `page` DISABLE KEYS */;
INSERT INTO `page` (`page_id`, `page_id_father`, `title`, `content`, `visible`, `lang_id`, `private`, `page_type_id`, `image`, `seo_title`, `seo_description`, `seo_keywords`, `date_created`, `date_changed`, `number_views`, `record_created_date`, `record_created_by`, `record_changed_date`, `record_changed_by`) VALUES
	(1, 0, 'Test page', 'Content of the page', 1, 2, 0, 1, '', 'Example', '', 'example', '0000-00-00 00:00:00', '0000-00-00 00:00:00', NULL, '0000-00-00 00:00:00', 0, NULL, NULL),
	(2, 0, 'Pagina de exemplo', 'Conteudo', 1, 1, 0, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', 0, NULL, NULL);
/*!40000 ALTER TABLE `page` ENABLE KEYS */;

-- Dumping structure for table esqueleto.page_type
CREATE TABLE IF NOT EXISTS `page_type` (
  `page_type_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`page_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- Dumping data for table esqueleto.page_type: ~2 rows (approximately)
/*!40000 ALTER TABLE `page_type` DISABLE KEYS */;
INSERT INTO `page_type` (`page_type_id`, `name`) VALUES
	(1, 'Normal');
/*!40000 ALTER TABLE `page_type` ENABLE KEYS */;

-- Dumping structure for table esqueleto.route
CREATE TABLE IF NOT EXISTS `route` (
  `route_id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `value` varchar(255) NOT NULL,
  `lang_id` int(10) NOT NULL,
  `valid` tinyint(4) NOT NULL DEFAULT '1',
  `generic` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`route_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8;

-- Dumping data for table esqueleto.route: ~5 rows (approximately)
/*!40000 ALTER TABLE `route` DISABLE KEYS */;
INSERT INTO `route` (`route_id`, `name`, `value`, `lang_id`, `valid`, `generic`) VALUES
	(1, 'ROUTE_PAGE', '/pagina', 1, 1, 0),
	(5, 'ROUTE_PAGE', '/page', 2, 1, 0),
	(11, 'ROUTE_HOME', '/inicio', 1, 1, 0),
	(12, 'ROUTE_HOME', '/home', 2, 1, 1),
	(20, 'ROUTE_REPORT_ERROR', '/report-error', 1, 1, 1);
/*!40000 ALTER TABLE `route` ENABLE KEYS */;

-- Dumping structure for visualização esqueleto.view_crud
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_crud` (
	`crud_id` INT(10) NOT NULL,
	`name` VARCHAR(255) NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for visualização esqueleto.view_page
-- Creating temporary table to overcome VIEW dependency errors
CREATE TABLE `view_page` (
	`page_id` INT(10) NOT NULL,
	`title` VARCHAR(255) NOT NULL COLLATE 'utf8_general_ci',
	`content` LONGTEXT NOT NULL COLLATE 'utf8_general_ci',
	`page_type_id` INT(10) NULL,
	`visible` TINYINT(4) NULL,
	`lang_id` INT(11) NOT NULL,
	`lang_name` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`lang_abbreviation` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`seo_title` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`seo_description` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`seo_keywords` VARCHAR(500) NULL COLLATE 'utf8_general_ci',
	`date_created` DATETIME NULL,
	`date_changed` DATETIME NULL,
	`number_views` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`private` TINYINT(4) NOT NULL,
	`image` VARCHAR(255) NULL COLLATE 'utf8_general_ci',
	`page_type` VARCHAR(255) NULL COLLATE 'utf8_general_ci'
) ENGINE=MyISAM;

-- Dumping structure for visualização esqueleto.view_crud
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_crud`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_crud` AS select `c`.`crud_id` AS `crud_id`,`c`.`name` AS `name` from `crud` `c` where (`c`.`crud_id` > 0) order by `c`.`crud_id` desc;

-- Dumping structure for visualização esqueleto.view_page
-- Removing temporary table and create final VIEW structure
DROP TABLE IF EXISTS `view_page`;
CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `view_page` AS select `p`.`page_id` AS `page_id`,`p`.`title` AS `title`,`p`.`content` AS `content`,`p`.`page_type_id` AS `page_type_id`,`p`.`visible` AS `visible`,`p`.`lang_id` AS `lang_id`,`p_l`.`name` AS `lang_name`,`p_l`.`abbreviation` AS `lang_abbreviation`,`p`.`seo_title` AS `seo_title`,`p`.`seo_description` AS `seo_description`,`p`.`seo_keywords` AS `seo_keywords`,`p`.`date_created` AS `date_created`,`p`.`date_changed` AS `date_changed`,`p`.`number_views` AS `number_views`,`p`.`private` AS `private`,`p`.`image` AS `image`,`p_t`.`name` AS `page_type` from ((`page` `p` left join `page_type` `p_t` on((`p`.`page_type_id` = `p_t`.`page_type_id`))) left join `language` `p_l` on((`p`.`lang_id` = `p_l`.`lang_id`))) order by `p`.`page_id` desc;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
